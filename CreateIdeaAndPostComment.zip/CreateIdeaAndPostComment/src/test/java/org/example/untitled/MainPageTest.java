package org.example.untitled;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import static java.util.concurrent.TimeUnit.SECONDS;

public class MainPageTest {


    WebDriver driver;
    WebDriverWait wait;


    @BeforeSuite
    public void  beforeTest() {

        System.setProperty("webdriver.chrome.driver", "./chromedriver");

        driver = new ChromeDriver();
        driver.manage().window().maximize();

        driver.get("https://trialqa.ideascale.com/");
        System.out.println("Browser Start");

    }

    @AfterSuite
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }

        System.out.println("\nDriver Quit\n");
    }
  @Test
  public void AcceptCookiesAndLogin() throws InterruptedException {


      wait = new WebDriverWait(driver,1000);

//      wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".btn:nth-child(2)")));

//      Thread.sleep(4000);
//      driver.manage().timeouts().implicitlyWait(4000, TimeUnit.MILLISECONDS);
      WebElement acceptCookies = driver.findElement(By.cssSelector(".btn:nth-child(2)"));
      acceptCookies.click();
//      wait.until(ExpectedConditions.elementToBeClickable(By.id("login-email")));
//      driver.manage().timeouts().implicitlyWait(5000, TimeUnit.MILLISECONDS);

      Thread.sleep(1000);
      WebElement email = driver.findElement(By.id("login-email"));
      email.sendKeys("trialqa.ideascale@gmail.com");

      WebElement password = driver.findElement(By.id("login-password"));
      password.sendKeys("a@123456#");

      WebElement login = driver.findElement(By.xpath("//button[@type='submit']"));
      login.click();

      wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"main-content\"]/div[1]/section/button")));

      Assert.assertEquals(driver.getCurrentUrl(),"https://trialqa.ideascale.com/c/");


  }

  @Test()
  public void createItem() throws InterruptedException {

        wait = new WebDriverWait(driver, 50);

//      Thread.sleep(10000);
      driver.manage().timeouts().implicitlyWait(10000, TimeUnit.MILLISECONDS);
      WebElement item = driver.findElement(By.xpath("//*[@id=\"main-content\"]/div[1]/section/button"));
      item.click();

      driver.manage().timeouts().implicitlyWait(5000, TimeUnit.MILLISECONDS);
      wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("title")));

//      Thread.sleep(5000);
      WebElement campaign = driver.findElement(By.cssSelector(".ideascale-select__control--is-focused .single-value"));
      campaign.click();
//      driver.manage().timeouts().implicitlyWait(4000, TimeUnit.MILLISECONDS);

      Thread.sleep(6000);
//      wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='react-select-3-option-0-0']/div/div/span")));



//    Select Campaign
      driver.findElement(By.xpath("//div[@id='react-select-3-option-0-0']/div/div/span")).click();
      Thread.sleep(2000);


      wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("title")));
//      driver.manage().timeouts().implicitlyWait(5000, TimeUnit.MILLISECONDS);

      WebElement title = driver.findElement(By.id("title"));
      title.sendKeys("Create New Test Idea.Win the trophy. New Idea");

      WebElement description = driver.findElement(By.xpath("//section/div/div[2]/div"));
      description.sendKeys("Create New Test Idea five.");

      JavascriptExecutor je = (JavascriptExecutor) driver;

      WebElement submit = driver.findElement(By.cssSelector(".btn-nest > .btn"));

      je.executeScript("arguments[0].scrollIntoView(true);",submit);

      submit.click();

      Thread.sleep(2000);

      driver.manage().timeouts().implicitlyWait(2000, TimeUnit.MILLISECONDS);
      WebElement close = driver.findElement(By.xpath("//*[@id=\"root\"]/div[3]/div/div/div[5]/div/button[1]"));
      close.click();
      Assert.assertEquals(driver.getCurrentUrl(),"https://trialqa.ideascale.com/c/");


  }

  @Test()
  public void postComment()
  {
//      WebElement search = driver.findElement(By.xpath("//*[@id=\"root\"]/div[1]/nav/div/ul/li[3]/button"));
//      search.click();

      WebElement searchText = driver.findElement(By.xpath("//*[@id=\"search\"]"));
      searchText.sendKeys("Create New Test Idea.Win the trophy. New Idea");



      WebElement clickSearch = driver.findElement(By.xpath("//*[@id=\"root\"]/div[1]/nav/div/div/form/div/div/button"));
      clickSearch.click();

      JavascriptExecutor je = (JavascriptExecutor) driver;
      WebElement commentIcon = driver.findElement(By.xpath("//*[@id=\"idea-390849\"]/header/h2/a"));
      je.executeScript("arguments[0].scrollIntoView(true);",commentIcon);
      commentIcon.click();

      driver.manage().timeouts().implicitlyWait(2000,TimeUnit.MILLISECONDS);

      WebElement commentText = driver.findElement(By.cssSelector(".ql-container > .ql-editor"));
      je.executeScript("arguments[0].scrollIntoView(true);",commentText);
      commentText.sendKeys("Comment Continue");

      WebElement submit = driver.findElement(By.xpath("//button[@type='submit']"));
      submit.click();

      driver.findElement(By.cssSelector(".btn-profile-menu > .avatar")).click();
      driver.findElement(By.linkText("Logout")).click();
  }
}